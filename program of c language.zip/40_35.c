//Print 1,10,2,9,3,8,4,7,5,6,
#include<stdio.h>
int main()
{    
    int i;
    for(i=0;i<=4;i++)
    {
      printf(" %d",i+1);
      printf(" %d",10-i);
    }
    return 0;
}
