// Accept one number from the user and display the sum of its digits.
#include<stdio.h>
int main()
{
   int n,sum=0,r;
   printf("eneter the number : ");
   scanf("%d",&n);
   for(;n>0;)
   {
       r=n%10;
       sum=sum+r;
       n=n/10;
   }
      printf("\n %d",sum);
    return 0;
}
