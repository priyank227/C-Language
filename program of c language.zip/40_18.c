//Enter value and check it is less, equal or greater than zero.
#include<stdio.h>
int main()
{
    int i;
    printf("\n enter the value of i:");
    scanf("%d",&i);
    if(i>0)
    {
      printf("\n %d is greater than zero ",i);   
     }
    else if(i<0)
    {
    printf("\n %d is less than zero",i);
    }
    else
    {
    printf("\n %d is eqqell zero",i);
    } 
     return 0;
    
}
