//get tha value of c,d,g,h and print the value of l.
//equation: l=(c+d)*(g+h)
#include<stdio.h>
int main()
{ 
	int c,d,g,h;
	int l;
	l=(c+d)*(g+h);
	printf("\n enter the value of c:");
	scanf("%d",&c);
	printf("\n enter the value of d:");
	scanf("%d",&d);
	printf("\n enter the value of g:");
	scanf("%d",&g);
	printf("\n enter the value of h:");
	scanf("%d",&h);
	l=(c+d)*(g+h);
	printf("\n %d",l);
	return 0;
}
