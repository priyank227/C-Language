/* Create a user define function named sum which accept 2 arguments 
(of integer type) and return the sum of them.*/

#include<stdio.h>
int sum(int,int);
int main()
{
    int i=32,j=12;
    printf("%d",sum(i,j));
    return 0;
}
int sum(int i,int j)
{
    return i+j;
}
