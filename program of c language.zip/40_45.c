//Accept one number from the user and find if it is Armstrong or not
#include<stdio.h>
int main()
{
	int n,i,j,sum=0;
	printf("eneter the number ");
	scanf("%d",&n);
	i=n;
	while(n>0)
	{
		j=n%10;
		sum=(j*j*j)+sum;
		n=n/10;
	}
    if(i==sum)
    {
       printf("%d is Armstrong number",i);
    }
    else
    {
        printf("%d is not Armstrong number",i);
    }
    return 0;
}
