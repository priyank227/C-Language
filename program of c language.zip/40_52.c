/*Print pattern like follow.
5
54
543
5432
54321*/

#include<stdio.h>
int main()
{
    int r,c;
    for(r=5;r>=1;r--)
    {
       for(c=5;c>=r;c--)
       printf("%d",c);
    printf("\n");
    }
    return 0;
}
