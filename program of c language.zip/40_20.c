//Write a program that interchange or swap the values of 2 variables.
#include<stdio.h>
int main()
{
	int a,b,c;
	printf("enter the value of a =");
	scanf("%d",&a);
	printf("enter the value of b =");
	scanf("%d",&b);
	c=a;
	a=b;
	b=c;
	printf("\n after swiping a=%d",a);
	printf("\n after swiping b=%d",b);
	return 0;
}
