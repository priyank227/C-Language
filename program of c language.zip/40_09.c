//Verify the formula s=((4*a+c)-2*a*b)/100
#include<stdio.h>
int main()
{
	float a,c,b;
	float s;
	printf("\n enter the value of a =");
	scanf("%f",&a);
	printf("\n enter the value of c =");
	scanf("%f",&c);
	printf("\n enter the value of b =");
	scanf("%f",&b);
	s=((4*a+c)-2*a*b)/100;
	printf("\n %f",s);
	return 0;
}
