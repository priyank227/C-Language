//Write a program to count the simple interest.
#include<stdio.h>
int main()
{
    int p,r,t;
    int a;
    printf("\n enter the value of p:");
    scanf("%d",&p);
    printf("\n enter the value of r:");
    scanf("%d",&r);
    printf("\n enter the value of t:");
    scanf("%d",&t);
    a=p*(1+(r*t));
    printf("\n final amount = %d",a);
     return 0;
}
