/* Write a program that take input of 5 subjects marks. If 
student get 40 or more then 40 then he is PASS in that 
subject otherwise FAIL print the result for following condition.
If student is pass in all subjects then declare PASS.
Is student is fail in 1 or 2 subject then declare ATKT.
If student is fail in more then 2 subject then declare FAIL.*/
#include<stdio.h>
int main()
{
	int i,j,k,l,m,fail=0;
	printf("enter the mark of subject 1 ");
	scanf("%d",&i);
	fail=fail+(i<40)?1:0;
	printf("\n enter the mark of subject 2 ");
	scanf("%d",&j);
		fail=fail+(j<40)?1:0;
	printf("\n enter the mark of subject 3 ");
	scanf("%d",&k);
		fail=fail+(k<40)?1:0;
	printf("\n enter the mark of subject 4 ");
	scanf("%d",&l);
		fail=fail+(l<40)?1:0;
	printf("\n enter the mark of subject 5 ");
	scanf("%d",&m);
		fail=fail+(m<40)?1:0;
	if(fail==0)
	{
		printf("\n PASS");
	}
	else if(fail==1 || fail==2)
	{
		printf("\n ATKT");
	}
	else
	{
		printf("\n FAIL");
	}
	return 0;
}
