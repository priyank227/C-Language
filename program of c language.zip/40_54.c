/*Print pattern like follow.
1
2 3
4 5 6
7 8 9 10
11 12 13 14 15*/

#include<stdio.h>
int main()
{
    int r,c,i;
    for(r=1;r<=5;r++)
    {
       for(c=1;c<=r;c++,i++)
       {
			printf(" %3d",i);
	   }   
		printf("\n");
    }
    return 0;
}
