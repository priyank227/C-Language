//print my name
#include<stdio.h>
    int main()
 {
    printf("priyank viradiya");
    return 0;
 }
