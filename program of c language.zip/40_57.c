/*Print pattern like follow.
5
45
345
2345
12345*/

#include<stdio.h>
int main()
{
	int r,c;
	for(r=5;r>=1;r--)
	{
		for(c=r;c>=1;c--)
		{
			printf("%d",c);
		}
    	printf("\n");
	}
    return 0;
}
