//Write a program to interchange the value of 2 variable without using 3rd variable
#include<stdio.h>
int main()
{
	int i,j;
	printf("\n enter the value of a=");
	scanf("%d",&i);
	printf("\n enter the valu of b=");
	scanf("%d",&j);
	i=i+j;
	j=i-j;
	i=i-j;
	printf("\n after swiping a =%d",i);
	printf("\n after swiping b =%d",j);
	return 0;
}
