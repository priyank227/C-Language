//Verify the formula c=(a+b)*(a+b)
#include<stdio.h>
int main()
{
	float a,b;
	float c;
	printf("\n enter the value of a =");
	scanf("%f",&a);
	printf("\n enter the value of b =");
	scanf("%f",&b);
	c=(a+b)*(a+b);
	printf("\n %f",c);
	return 0;
}
