//get the value of i,j and print its square and cube 
#include<stdio.h>
int main()
{
	int i,j;
	int k,l,m,n;
	printf("\n enter value of i :");
	scanf("%d,%d",&i);
	printf("\n enter value of j :");
	scanf("%d,%d",&j);
	k=i*i;
	l=i*i*i;
	m=j*j;
	n=j*j*j;
	printf("\n square of i = %d",k);
	printf("\n cube of i = %d",l);
	printf("\n square of j = %d",m);
	printf("\n square of j = %d",n);
	return 0; 
}
