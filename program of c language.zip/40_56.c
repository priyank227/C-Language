/*Print pattern like follow.
z
y x
w v u
t s r q
p o n m l
*/
#include<stdio.h>
int main()
{
    int r,c;
    char j='z';
    for(r=0;r<5;r++)
    {
        for(c=0;c<=r;c++)
        {
          printf("%2c",j--);
        }
    	printf("\n");
	}
    return 0;
}
