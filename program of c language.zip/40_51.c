/*Print pattern like follow.
1
22
333
4444
55555*/

#include<stdio.h>
int main()
{
    int r,c;
    for(r=1;r<=5;r++)
    {
       for(c=1;c<=r;c++)
       printf("%d",r);
    printf("\n");
    }
    return 0;
}
