// Accept one number from the user and display its factorial.
#include<stdio.h>
int main()
{
	int n,i=1;
    printf("enter the number :");
    scanf("%d",&n);
	for(n;n>0;n--)
	{
		i=i*n;
	}
	printf("%d",i);
    return 0;
}
