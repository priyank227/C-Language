// 0.1+0.02+0.003+0.0004+0.000005.
#include<stdio.h>
int main()
{
   int i;
   float sum=0,n=10.0;
   for(i=1;i<=5;i++)
	{ 
		sum=sum+i/n;
		n=n*10.0;
	}
	printf("%f",sum);
    return 0;
}
