/*Write a program that performs the following output for n rows
1
3
5 6
8 9 10*/

#include<stdio.h>
int main()
{
	int i,j,n=1;
	for(i=0;i<4;i++)
	{
		j=0;
		do
		{
			printf("%d ",n);
			n++;
			j++;
		}
    	while(j<i);
		n++;
		printf("\n");
	 }
	return 0;
}
    
