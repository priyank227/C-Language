//Accept one number from the user and find if it is prime or not.
#include<stdio.h>
int main()
{
    int n,i,k=0;
    printf("eneter the number : ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
		if(n%i==0)
		{
			k++;
		}
	}
	if(k==2)
	{
    	printf("the number is prime");
    }
	else
	{
		printf("number is not prime");
	}
    return 0;
}
