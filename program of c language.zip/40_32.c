//Print 2,4,6,8,10.
#include<stdio.h>
int main()
{
	int i;
	for(i=2;i<=10;i++)
	{	
		if(i%2==0)
		{
			printf("\n %d",i);
		}
	}
	return 0;
}
