//Write a program to check whether the entered no is odd or even.
#include<stdio.h>
int main()
{
	int no;
	printf("\n Enter no to Check EVEN or ODD=");
	scanf("%d",&no);
	
	if(no%2==0)
	{
		printf("\n %d is EVEN",no);
	}
	else
	{
		printf("\n %d is ODD",no);
	}
	
	return 0;
}
