//Get a character in lower case form user and display it in upper case.
#include<stdio.h>
int main()
{
	char ch;
	printf("\n enter the alphabet in lower case :");
	scanf("%c",&ch);
	if(ch>='a'&&ch<='z')
	{
		printf("%c->%c",ch,ch-'a'+'A');
	}
	else
	{
		printf("Enter valid alphabet");
	}
	return 0;
	
}
