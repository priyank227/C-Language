//Generate the value of n! factorial for n number
#include<stdio.h>  
int main()    
{    
	int i,j=1,n;    
	printf("Enter the number: ");    
	scanf("%d",&n); 
	do
	{ 
    	for(i=1;i<=n;i++)
		{    
    		j=j*i;    
		}    
		printf("\n Factorial of %d is : %d",n,j);   
		n--; 
		j=1;
	}
	while(n>0);
	return 0;  
} 
