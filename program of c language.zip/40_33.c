//Print 1,2,4,8,16,32,64.
#include<stdio.h>
int main()
{
    int i,j;
    for(i=1;i<=7;i++)
    {
		printf("\n %d",j);
		j=j+j;
    }
    return 0;
}
