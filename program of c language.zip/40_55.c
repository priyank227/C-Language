/* Print pattern like follow.
1
01
010
1010
10101 */

#include<stdio.h>
int main()
{
    int r,c,i=1;
    for(r=1;r<=5;r++)
	{
		for(c=1;c<=r;c++)
		{
			if(i%2==0)
			{
				printf("0");
        	}
			else
        	{
        		printf("1"); 
        	}
			i++;
		}
		printf("\n");
    }
    return 0;
}
