//Accept one number from the user and display the Reverse of it.
#include<stdio.h>
int main()
{
   int n;
   printf("enter the number :");
   scanf("%d",&n);
   for(;n>0;)
   {
      printf("%d",n%10);
      n=n/10;
   }
     return 0;
    
}
