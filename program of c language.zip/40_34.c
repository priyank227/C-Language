//Print 10 to 1
#include<stdio.h>
int main()
{
   int i=10;
   for(i;i>=1;i--)
   {
    	printf("\n %d",i);
   }
    return 0;
}
