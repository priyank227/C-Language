//Write a program to find maximum from 3 values using conditional operator
#include<stdio.h>
int main()
{
	int a,b,c;
	printf("\n enter the values:");
	scanf("%d %d %d",&a,&b,&c);
	
	(a>b && a>c)?printf("\n max is %d",a):( b>a && b>c )?printf("\n max is %d",b) : printf("\n max is %d",b);
	
	return 0;
}
