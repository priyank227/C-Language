//print address
#include<stdio.h>
    int main()
 {
    printf("'radhe shyam'");
    printf("\n shraddha Park 3 street no 5 near d mart");    
    printf("\n rajkot");
    printf("\n 360002");
    return 0;
 }
