/*Write a program that count the area for circle, square, 
rectangle and triangle using Switch-Case control structure*/
#include<stdio.h>
int main()
{
	int i;
	float r,k,l,m,a;
	printf("\n 1 area of circle \n 2 area of square \n 3 area of rectangle \n 4 area of triangle\n");
	printf("\n enter shape :");
	scanf("%d",&i);
	switch(i)
	{
		case 1:
		  printf("\n enter the value of radius:");
		  scanf("%f",&r);
		  a=3.14*r*r;
		  printf("\n area of circle : %f",a);
		  break;
		case 2:
		  printf("\n enter the value of side leangh:");
		  scanf("%f",&k);
		  a=k*k;
		  printf("\n area of square : %f",a);
		  break;
		  case 3:
		  printf("\n enter the value of side leangh:");
		  scanf("%f",&l);
		  printf("\n enter the value of width leangh:");
		  scanf("%f",&m);
		  a=l*m;
		  printf("\n area of circle : %f",a);
		  break;
		  case 4:
		  printf("\n enter the hight :");
		  scanf("%f",&l);
		  printf("\n enter the base :");
		  scanf("%f",&m);
		  a=(l*m)/2;
		  printf("\n area of circle : %f",a);
		  break;
		  default:
		  printf("\n enter the choice bitween 1 to 4");
   }
	return 0;
}

