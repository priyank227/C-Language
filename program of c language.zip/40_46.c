//Print 0 1 1 2 3 5 8 13 21 34 55 � (Fibonanci series)
#include<stdio.h>
int main()
{
	int n,n1=0,n2=1,n3,i;
	printf("enter the number of element: ");
	scanf("%d",&n);
	printf("\n %d %d",n1,n2);

	for(i=2;i<n;i++)
	{
    	n3=n1+n2;
    	printf(" %d",n3);
    	n1=n2;
    	n2=n3;
	}
    return 0;
}
