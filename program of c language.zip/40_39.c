//Print the total of 1/2+2/3+....+9/10.
#include<stdio.h>
int main()
{
    int i;
    float sum=0;
    for(i=1;i<10;i++)
    {
       sum = sum + i/(i+1.0);
    }
    printf("%f",sum);
    return 0;
}
