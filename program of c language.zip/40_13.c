//Calculate the area of Triangle.
#include<stdio.h>
int main()
{
    int h,b;
    int l;
    printf("\n enter the value of h:");
    scanf("%d",&h);
    printf("\n enter the value of b:");
    scanf("%d",&b);
    l=(h*b)/2;
    printf("\n area= %d",l);
    return 0;
}
