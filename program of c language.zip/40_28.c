/* Write a program that take input of year in 4 digit. Determine 
whether the year is leap year or not.(try to solve this problem with 
&& and or operator)*/

#include<stdio.h>
int main()
{
	int i;
	printf("\n enter the year:");
	scanf("%d",&i);
	if(i%4==0)
	{
    	if(i%100==0 && i%400!=0)
	    {
			printf("\n %d is not leap yaer",i);
    	}
	else
    	{
			printf("\n %d is leap year",i);
    	}
    }
	else
   {
		printf("\n %d is not leap year",i);
   }
  
	return 0;
}

