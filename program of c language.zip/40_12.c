//Calculate the area of Circle.
#include<stdio.h>
int main()
{
    int r;
    int l;
    printf("\n enter the value of r:");
    scanf("%d",&r);
    l=(3.14*(r*r))
    printf("\n area of circlr = %d",l);
    return 0;
}
