//Verify the formula t=((v+s)+(l-m)*l)
#include<stdio.h>
int main()
{
    double v,s,l,m;
    double t;
    printf("\n enter the value of v :");
    scanf("%lf",&v);
    printf("\n enter the value of s :");
    scanf("%lf",&s);
    printf("\n enter the value of l :");
    scanf("%lf",&l);
    printf("\n enter the value of m :");
    scanf("%lf",&m);
    t=((v+s)+(l-m)*l);
    printf("\n %lf",t);
    return 0;

}
