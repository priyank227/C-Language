//Write a C Program which accepts n numbers in an array and display it
#include<stdio.h>
int main()
{
	int a[5],i;
	for(i=0;i<5;i++)
	{
		printf("a[%d]=",i);
		scanf("%d",&a[i]);
	}
	for(i=0;i<5;i++)
	{
		printf("\n%d",a[i]);
	}
	return 0;
}
