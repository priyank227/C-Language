//get the value of i and j and print its sum
#include<stdio.h>
int main()
{ 
   int i,j;
   int k;
   printf("\n enter value of i and j :");
   scanf("%d,%d",&i,&j);
   k=i+j;
   printf("\n%d",i+j);
   return 0;
}
