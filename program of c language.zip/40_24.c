//Get a character from user and print tell that is it vowel or consonant. [Switch Case]
#include<stdio.h>
int main()
{
	char ch;
	printf("\n enter the value of ch=");
	scanf("%c",&ch);
	switch(ch)
	{
		case'a':
		{
			printf("vowel");
		}
		break;
		
		case'e':
		{
			printf("vowel");		
		}
		break;
		
		case'i':
		{
			printf("vowel");
		}
		break;
		
		case'o':
		{
			printf("vowel");
	    }
	    break;
	    
		case'u':
		{
	    	printf("vowel");
		}
		break;
		
		case'A':
		{
			printf("vowel");
		}
		break;
		
		case'E':
		{
			printf("vowel");
    	}
    	break;
    	
		case'I':
		{
			printf("vowel");
		}
		break;
		
		case'O':
		{
			printf("vowel");
		}
		break;
		
		case'U':
    	{
	    	printf("vowel");
    	}
		break;
		default:
		printf("consonant");
	}
		return 0;
		
}
