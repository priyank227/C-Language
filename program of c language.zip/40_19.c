//Write a program that find minimum and maximum out of 3 values.
#include<stdio.h>
int main()
{
	int i,j,k;
	printf("\n enter the value of i= ");
	scanf("%d",&i);
	printf("\n enter the value of j= ");
	scanf("%d",&j);
	printf("\n enter the value of k= ");
	scanf("%d",&k);
	
	if(i>j && i>k)
	{
		printf("\n maximum value is = %d",i);
	}
	else if(j>i && j>k)
	{
		printf("\n maximum value is = %d",j);
	}
	else
	{
	printf("\n maximum value is = %d",k);
    }
    
    
	if(i>j && k>j)
	{
		printf("\n minimum value is = %d",j);
	}
	else if(j>i && k>i)
	{
		printf("\n manimum value is = %d",i);
	}
	else
	{
		printf("\n manimum value is = %d",k);
    }
    return 0;
}
