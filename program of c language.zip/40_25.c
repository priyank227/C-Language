/* Write a program that take input of 5 subjects marks. Count 
the percentage. Print the result for following condition
If student has 70% or more then 70% then DISTINCTION.
If student has percentage between 60 and 69 then FIRST 
CLASS.
If student has percentage between 50 and 59 then SECOND 
CLASS.
If student has percentage between 40 and 49 then PASS 
CLASS.
If student has percentage less then 40 then FAIL.*/
#include<stdio.h>
int main()
{
	int i,j,k,l,m;
	int total;
	float p;
	printf("\n enter the mark of subject 1: ");
	scanf("%d",&i);
	printf("\n enter the mark of subject 2: ");
	scanf("%d",&j);
	printf("\n enter the mark of subject 3: ");
	scanf("%d",&k);
	printf("\n enter the mark of subject 4: ");
	scanf("%d",&l);
	printf("\n enter the mark of subject 5: ");
	scanf("%d",&m);
	
	total=i+j+k+l+m;
	p=total/5;
	
	if(p>=70)
	{
	printf("\n distinction");
    }
    else if(p>=60)
    {
    	printf("\n first class");
	}
	else if(p>=50)
    {
    	printf("\n second class");
	}
	else if(p>=40)
    {
    	printf("\n pass class");
	}
	else
	{
		printf("\n fail");
	}
	return 0;
	
}
