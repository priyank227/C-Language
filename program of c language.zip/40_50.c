/*. Print pattern like follow.
A A A A A
B B B B B
C C C C C
D D D D D
E E E E E
*/

#include<stdio.h>
int main()
{
    char r,c;
    for(r='A';r<='E';r++)
    {
		for(c='A';c<='E';c++)
		{
			printf("%c",r);
		}
		printf("\n");
    }
    return 0;
}
