//Accept 2 numbers from the user and print its GCD and LCM
#include<stdio.h>
int main()
{
	int n1,n2,n,r,k,lcm,gcd;
	printf("enter the value of n1:");
	scanf("%d",&n1);
	printf("enter the value of n2:");
	scanf("%d",&n2);
	if(n1>n2)
	{
		n=n1;
		k=n2;
	}
	else 
	{
		n=n2;
		k=n1;
	}
	r=n%k;
	while(r!=0)
	{
		n=k;
		k=r;
		r=n%k;	
	}
	gcd=k;
	lcm=n1*n2/gcd;
	printf("GCD of %d and %d = %d\n",n1,n2,gcd);
	printf("LCM of %d and %d = %d\n",n1,n2,lcm);
	return 0;
}
