//Input a Rupees and prints its value converted into Dollar.
#include<stdio.h>
int main()
{
	float rupee;
	float doller;
	printf("enter the value of rupee=");
	scanf("%f",&rupee);
	doller=rupee/76;
	printf("\n doller= %f",doller);
	return 0;
}
