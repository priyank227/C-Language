//get the value of i,j and print its sum, aub, mul, div.
#include<stdio.h>

int main()
{
    int i,j;
    printf("enter the value of i=");
    scanf("%d",&i);
    
    printf("enter the value of j=");
    scanf("%d",&j);
    
    printf("\n addition = %d",i+j);
    printf("\n subtraction = %d",i-j);
    printf("\n multiplication = %d",i*j);
    printf("\n division = %d",i/j);
    
     return 0;
}
