//Print first 100 odd numbers.
#include<stdio.h>
int main()
{
	int i;
	for(i=0;i<=200;i++)
	{
		if(i%2==!0)
		{
    	  printf(" %d",i);
    	}
	}
    return 0;
}
