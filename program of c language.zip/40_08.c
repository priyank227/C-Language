//Verify the formula x=((k-4)*(a*4))/100.
#include<stdio.h>
int main()
{
  float k,a;
  float x;
  printf("\n enter the value of k:"); 
  scanf("%f,%f",&k);
  printf("\n enter the value of a:"); 
  scanf("%f,%f",&a);
  x=((k-4)*(a*4))/100;
  printf("\n %f",x);
  return 0;
}
