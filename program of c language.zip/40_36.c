//Print 1,11,20,28,35,41,46,50,53,55,56.
#include<stdio.h>
int main()
{
    int i=10,j=1;
    for(i;i>=0;i--)
    {
       printf(" %d",j);
       j=j+i;
    }
    return 0;
}
