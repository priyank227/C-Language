//print c programming
#include<stdio.h>
    int main()
 {
    printf("c programming");
    return 0;
 }
