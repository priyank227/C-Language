//Input a Number of Chairs and its Total Cost and Prints the Cost of Each chair.
#include<stdio.h>
int main()
{
	int i,j;
	int k;
	printf("\n enter the number of chair = ");
	scanf("%d",&i);
	printf("\n enter total cost of chair = ");
	scanf("%d",&j);
	k=j/i;
	printf("\n cost of each chair = %d",k);
	return 0;
}
