//Verify the formula a=p*(1+(r/100)/n)-p
#include<stdio.h>
int main()
{
	float p,r,n;
	float a;
	printf("\n enter the value of p =");
	scanf("%f",&p);
	printf("\n enter the value of r =");
	scanf("%f",&r);
	printf("\n enter the value of n =");
	scanf("%f",&n);
	a=p*(1+(r/100)/n)-p;
	printf("\n %f",a);
	return 0;
}
