/* Print pattern like follow.
2 4 6 8 10
4 6 8 10
6 8 10
8 10
10*/

#include<stdio.h>
int main()
{
	int r,c;
	for(r=2;r<=10;r++)
    { 
    	for(c=r;c<=10;c++)
    	{   
        	if(r%2==0 && c%2==0)
            printf("%3d",c);   
        }
        printf("\n");
    }
    return 0;
}
